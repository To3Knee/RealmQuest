# D&D Custom Vocabulary/Dictionary (v1.0.0)

Generated: **2026-01-27**  
Entries: **406**

This dataset is designed for **LLM retrieval** and database ingestion. It includes:
- D&D/tabletop **lingo**, **abbreviations**, **rules terms**, **combat**, **spellcasting concepts**, **conditions**, **damage types**, **creature types**
- **Worldbuilding** and **tavern** vocabulary (foods/drinks, locations, NPC roles)
- **Languages** and **dialect/cant** flavor entries
- **Meta/table culture** vocabulary (session zero, house rules, slang)

> Note: This is **not** an exhaustive dump of every copyrighted spell/monster/name across all published products.  
> It is a **high-coverage, reusable vocabulary** foundation meant to be extended with your own setting-specific or product-specific catalogs.

## Files

- `dnd-custom-dictionary-v1.0.0.jsonl` (recommended for LLM ingestion)
- `dnd-custom-dictionary-v1.0.0.csv` (spreadsheet/ETL friendly)
- `dnd-custom-dictionary-schema-v1.0.0.sql` (Postgres table)

## JSONL format

The first line is a `meta` record. Every following line is an entry with fields:

- `id` (stable identifier)
- `term`
- `aliases` (array)
- `category`, `subcategory`
- `edition` (ex: `5e`, `5e-generic`, etc.)
- `definition`
- `usage_notes`
- `examples` (array)
- `related_terms` (array)
- `tags` (array)
- `source`

## Postgres import (JSONL → JSONB fields)

**Option A: Ingest with a small script (recommended)**

Pseudo-steps:
1. Run the schema SQL to create table.
2. Read JSONL line by line.
3. Skip the first meta line.
4. Insert each entry.

**Option B: CSV import**
1. Create your own table with TEXT columns for arrays then transform, or
2. Use an ETL tool (Airbyte/dbt/Pandas) to map CSV columns into JSONB.

## Embedding pipeline suggestion

For retrieval:
- Create an embedding text like:
  - `term + aliases + category/subcategory + definition + usage_notes + examples`
- Store:
  - `embedding`, `term`, `category`, `tags`, and the full JSON entry.
- Retrieval:
  - Filter by `category/tags/edition` when helpful.

## Versioning

- Dataset version: `v1.0.0`
- Regenerate as you extend terms for your setting.
