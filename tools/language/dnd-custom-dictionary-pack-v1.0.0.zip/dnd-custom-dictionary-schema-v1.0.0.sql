-- D&D Custom Vocabulary/Dictionary Schema
-- Version: 1.0.0
-- Generated: 2026-01-27

CREATE TABLE IF NOT EXISTS dnd_dictionary (
  id TEXT PRIMARY KEY,
  term TEXT NOT NULL,
  aliases JSONB NOT NULL DEFAULT '[]'::jsonb,
  category TEXT NOT NULL,
  subcategory TEXT NOT NULL,
  edition TEXT NOT NULL,
  definition TEXT NOT NULL,
  usage_notes TEXT NOT NULL DEFAULT '',
  examples JSONB NOT NULL DEFAULT '[]'::jsonb,
  related_terms JSONB NOT NULL DEFAULT '[]'::jsonb,
  tags JSONB NOT NULL DEFAULT '[]'::jsonb,
  source TEXT NOT NULL DEFAULT ''
);

-- Optional: simple search indexes
CREATE INDEX IF NOT EXISTS dnd_dictionary_term_idx ON dnd_dictionary (term);
CREATE INDEX IF NOT EXISTS dnd_dictionary_category_idx ON dnd_dictionary (category);
CREATE INDEX IF NOT EXISTS dnd_dictionary_subcategory_idx ON dnd_dictionary (subcategory);

-- If you want full-text search (Postgres), uncomment:
-- CREATE INDEX IF NOT EXISTS dnd_dictionary_fts_idx
--   ON dnd_dictionary
--   USING GIN (to_tsvector('english', term || ' ' || definition || ' ' || usage_notes));
