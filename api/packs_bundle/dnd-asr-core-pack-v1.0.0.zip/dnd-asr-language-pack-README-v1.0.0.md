# D&D ASR Language Pack (v1.0.0)

Generated: **2026-01-27**  
Rules: **299**

This pack is for **speech-to-text (ASR) cleanup** and **LLM DM input normalization**.
It maps likely mishearings like:
- `tavern` ⇐ `cavern`
- `ale` ⇐ `nail`
- `barmaid` ⇐ `bar made`
- `initiative` ⇐ `roll an issue`
…and many more.

## Files
- `dnd-asr-language-pack-v1.0.0.jsonl` (recommended)
- `dnd-asr-language-pack-v1.0.0.csv`

## Schema (per row)
- `heard`: what ASR produced
- `canonical`: what you want
- `type`: `phrase` | `regex` | `word` | `hint`
- `confidence`: how safe the correction is (0–1)
- `priority`: apply order (higher first)
- `context_include` / `context_exclude`: optional gates for ambiguous cases
- `notes`, `example_in`, `example_out`

## Recommended application strategy

### 1) Phrase pass (high priority)
Replace high-confidence phrases first:
- Example: `walk into the cavern` → `walk into the tavern`

### 2) Guarded regex pass (optional but recommended)
Only apply **ambiguous** fixes when context matches:
- Example: `life` → `like` only when in frames like `I _ to`, `I'd _ to`, etc.
- Example: `cavern` → `tavern` only when words like `ale/bar/barkeep` are nearby.

### 3) Word pass
Apply high-confidence word substitutions.

### 4) Hints (ASR biasing, not replacement)
Rows with `type=hint` are intended as **custom vocabulary/phrase hints** for your ASR engine.

## Practical defaults
- Apply only rules with `confidence >= 0.80` unless context gates pass.
- Keep `auto_variant` rules disabled unless ASR confidence is low.
- Log every applied correction for debugging.

## Example normalization pipeline (pseudocode)
1. Normalize text (lowercase, strip punctuation except apostrophes)
2. Apply phrase rules (priority desc)
3. Apply guarded regex rules when context matches
4. Apply word rules
5. Emit corrected text + list of applied rules

